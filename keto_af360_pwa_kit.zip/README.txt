
# Keto Air Fryer 360° — Kit PWA (para GitHub Pages u hosting propio)

## Qué incluye
- `index.html` (lanzador con 3 botones + visor incrustado)
- `plan.html` (tu Plan 7 Días)
- `lista.html` (Lista de Compras)
- `snacks.html` (Snacks Express)
- `manifest.webmanifest` (PWA)
- `service-worker.js` (cache offline)
- `icons/` (iconos 192/512 px)

## Cómo desplegar en GitHub Pages
1. Crea un repo llamado `keto-af360` (o el nombre que prefieras).
2. Sube todos los archivos de esta carpeta a la rama `main` en la raíz.
3. En **Settings → Pages**, elige **Branch: main / root** y guarda.
4. Abre la URL de Pages. Deberías ver `index.html`.
5. Agrega `?p=plan` (o `?p=lista` / `?p=snacks`) para abrir directo una sección.

## Cómo desplegar en Hostinger (o cualquier hosting)
1. Sube toda la carpeta al **public_html** (o carpeta pública).
2. Asegúrate que `index.html` esté en la raíz pública.
3. Verifica que al abrir el dominio, se muestre el lanzador.
4. Prueba la instalación como app desde el navegador del móvil.

## Notas para Hotmart
- Publica un enlace de acceso en tu producto que apunte a `index.html` (GitHub Pages o tu hosting).
- En el área de miembros, crea una lección con ese enlace. 
- Para protección, entrega el enlace solo a compradores y usa las opciones de acceso/garantía de Hotmart.

## Consejos
- Evita `#` y espacios en nombres de archivo. Ya fueron renombrados a `plan.html`, `lista.html`, `snacks.html` para máximo soporte.
- Si actualizas contenido, aumenta la versión de `CACHE_NAME` en `service-worker.js` para forzar recarga.
- En iPhone: instala desde **Compartir → Añadir a pantalla de inicio**.
